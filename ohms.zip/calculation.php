 <?php
 
$num=trim($_GET["a"]);
$num1=trim($_GET["b"]);
  echo $num + $num1 ."<br>";

?>