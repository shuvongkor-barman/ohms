<?php
$dbuser="root";
$dbpass="rootpassword";
$host="localhost";
$db="diuohmsx_hostel";
$mysqli =new mysqli($host, $dbuser, $dbpass, $db);
?>